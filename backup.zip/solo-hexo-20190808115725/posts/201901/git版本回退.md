title: git版本回退
date: '2019-01-04 17:29:15'
updated: '2019-07-09 14:43:34'
tags: [git]
permalink: /articles/2019/01/04/1546594155112.html
---
![](https://img.hacpai.com/bing/20180823.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# git版本回退

git放弃本地的修改，与远程仓库同步

```sh
#指令是下载远程仓库最新内容，不做合并 
git fetch --all
#把HEAD指向master最新版本
git reset --hard origin/master
#远程拉取更新
git pull
```

