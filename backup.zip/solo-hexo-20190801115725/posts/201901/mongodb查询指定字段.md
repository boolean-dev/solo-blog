title: mongodb查询指定字段
date: '2019-01-23 21:51:00'
updated: '2019-01-23 21:51:00'
tags: [mongodb]
permalink: /articles/2019/01/23/1548251460416.html
---
## mongodb查询指定字段

```java
    @Test
    public void fun1() {

        DBObject fieldsObject = new BasicDBObject();
        fieldsObject.put("_id", true);
        fieldsObject.put("name", true);
        fieldsObject.put("code", true);
        fieldsObject.put("marketPrice", true);

        BasicDBObject dbObject = new BasicDBObject();
        fieldsObject.put("productId", "PD329321375342788608");

        Query query = new BasicQuery(dbObject,fieldsObject);

        List<Goods> goodsList = mongoTemplate.find(query, Goods.class);
        String gson = new Gson().toJson(goodsList);
        System.out.println(gson);
    }
```

