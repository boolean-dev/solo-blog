title: 我在 GitHub 上的开源项目
date: '2019-07-10 14:35:19'
updated: '2019-07-10 14:35:19'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [goods](https://github.com/boolean-dev/goods) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/boolean-dev/goods/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/boolean-dev/goods/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/boolean-dev/goods/network/members "分叉数")</span>

网络书城源码



---

### 2. [solo-blog](https://github.com/boolean-dev/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/boolean-dev/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/boolean-dev/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/boolean-dev/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://blog.booleandev.xyz`](https://blog.booleandev.xyz "项目主页")</span>

boolean-dev 的个人博客 - 记录精彩的程序人生



---

### 3. [note](https://github.com/boolean-dev/note) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/boolean-dev/note/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/boolean-dev/note/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/boolean-dev/note/network/members "分叉数")</span>

日常笔记



---

### 4. [security](https://github.com/boolean-dev/security) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/boolean-dev/security/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/boolean-dev/security/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/boolean-dev/security/network/members "分叉数")</span>

spring security demo



---

### 5. [blog](https://github.com/boolean-dev/blog) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/boolean-dev/blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/boolean-dev/blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/boolean-dev/blog/network/members "分叉数")</span>

blog whit slol



---

### 6. [java-example](https://github.com/boolean-dev/java-example) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/boolean-dev/java-example/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/boolean-dev/java-example/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/boolean-dev/java-example/network/members "分叉数")</span>

java一些项目示例



---

### 7. [design-patterns](https://github.com/boolean-dev/design-patterns) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/boolean-dev/design-patterns/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/boolean-dev/design-patterns/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/boolean-dev/design-patterns/network/members "分叉数")</span>

阅读书籍 《Head Frist 设计模式》练习代码



---

### 8. [code-generate](https://github.com/boolean-dev/code-generate) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/boolean-dev/code-generate/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/boolean-dev/code-generate/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/boolean-dev/code-generate/network/members "分叉数")</span>

代码一键生成



---

### 9. [miniapp](https://github.com/boolean-dev/miniapp) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/boolean-dev/miniapp/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/boolean-dev/miniapp/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/boolean-dev/miniapp/network/members "分叉数")</span>

小程序



---

### 10. [springboot-web](https://github.com/boolean-dev/springboot-web) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/boolean-dev/springboot-web/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/boolean-dev/springboot-web/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/boolean-dev/springboot-web/network/members "分叉数")</span>

springboot脚手架

