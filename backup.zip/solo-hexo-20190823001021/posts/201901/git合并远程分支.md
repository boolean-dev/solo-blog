title: git合并远程分支
date: '2019-01-04 17:27:31'
updated: '2019-07-09 14:43:01'
tags: [git]
permalink: /articles/2019/01/04/1546594051488.html
---
![](https://img.hacpai.com/bing/20190620.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### git合并远程分支

```sh
# 1. 把源码clone到本地
git clone [gitsite  git远程网址]
# 2. 在本地建立一个和远程分支相同的本地分支
git checkout -b dev origin/dev
# 3. 切换到主分支master
git checkout master
# 4. 将本地的dev合并到本地主分支master中
git merge dev
# 5. 将本地主分支master同步到远程
git push origin master
# 6.删除远程分支
git branch --delete --remotes <remote>/<branch>
```

