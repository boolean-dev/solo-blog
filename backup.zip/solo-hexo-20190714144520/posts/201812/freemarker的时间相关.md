title: freemarker的时间相关
date: '2018-12-25 16:38:24'
updated: '2019-07-09 14:38:14'
tags: [freemark, java, springboot]
permalink: /articles/2018/12/25/1545726842373.html
---
![](https://img.hacpai.com/bing/20190512.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 1.freemarker的时间转换

```
	//标准日期转日期字符串
	${parameters.fieldDate?date} 
	//标准日期转日期+时间 字符串
	${parameters.fieldDate?datetime}
	//标准日期转自定格式 字符串
	${parameters.fieldDate?string("yyyy-MM-dd HH:mm:ss")} 

```

## 2.freemarker的时间比较

```
	//年月日时分秒比较
	<#if startTime?datetime lt .now?datetime>
	//年月日比较
	<#if startTime?date lt .now?date>
	//时分秒比较
	<#if startTime?time lt .now?time>

```

## 3.freemarker的年龄的计算

```
	//只通过年份计算年龄(当出生年月会报错时，则会报错
	${((.now?string("yyyy"))!)?number - ((date?string("yyyy"))!)?number}
	//只通过年份计算年龄，当出生年月为空时，则当前年龄为0
	${((.now?string("yyyy"))!)?number - ((coupon.usedDate?string("yyyy"))!(.now?string("yyyy")))?number}

```
