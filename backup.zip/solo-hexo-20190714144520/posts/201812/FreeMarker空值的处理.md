title: FreeMarker空值的处理
date: '2018-12-25 16:49:53'
updated: '2019-07-09 14:38:38'
tags: [freemark, java, springboot]
permalink: /articles/2018/12/25/1545727792970.html
---
![](https://img.hacpai.com/bing/20171109.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 判断元素是否存在

```
	user.name?exists 
	user.name?? 
	<#if user.name?exists>
	 //TO DO
	</#if>
	 
	<#if user.age??>
	 //TO DO
	</#if>

```

### 忽略空值

```
	假设前提：user.name为null 
	${user.name}//异常 
	${user.name!}//显示空白 
	${user.name!'vakin'}//若user.name不为空则显示本身的值，否则显示vakin 
	${user.name?default('vakin')}//同上 
	${user.name???string(user.name,'vakin')}//同上

```